// DOM要素
const titleInput = document.getElementById('titleInput');
const pageContentTextarea = document.getElementById('pageContent');
const charCountSpan = document.getElementById('charCount');
const aspectRatioSelect = document.getElementById('aspectRatio');
const generateButtons = document.querySelectorAll('.generate-btn');
const apiSettingsBtn = document.getElementById('apiSettingsBtn');
const apiModal = document.getElementById('apiModal');
const apiKeyInput = document.getElementById('apiKeyInput');
const saveApiBtn = document.getElementById('saveApiBtn');
const cancelApiBtn = document.getElementById('cancelApiBtn');
const closeModal = document.querySelector('.close');
const imageModal = document.getElementById('imageModal');
const modalImage = document.getElementById('modalImage');
const toastElement = document.getElementById('toast');

let currentPageContent = '';
let falApiKey = null;
let generatedImages = {}; // スタイルごとの生成画像を保存
let designConfig = null; // デザイン設定
let designGroups = []; // デザイングループのリスト
let activeTab = 'home'; // 現在アクティブなタブ
let currentEditingGroupId = null; // 現在編集中のグループID
let tempDesigns = []; // 編集中のデザイン一時保存
let characterImageBase64 = null; // キャラクター画像のBase64データ
let designImageBase64 = null; // デザイン参考画像のBase64データ

// トースト表示関数
function showToast(message, duration = 5000) {
  toastElement.textContent = message;
  toastElement.classList.add('show');

  setTimeout(() => {
    toastElement.classList.remove('show');
  }, duration);
}

// 初期化
document.addEventListener('DOMContentLoaded', async () => {
  // デザイン設定を読み込む
  await loadDesignConfig();

  // デザイングループを読み込む
  await loadDesignGroups();

  // URLパラメータからページ内容を取得（background.jsから渡される）
  const urlParams = new URLSearchParams(window.location.search);
  const contentParam = urlParams.get('content');

  if (contentParam) {
    currentPageContent = decodeURIComponent(contentParam);
    pageContentTextarea.value = currentPageContent;
    updateCharCount();
  } else {
    // ストレージから取得
    const result = await chrome.storage.local.get('pendingPageContent');
    if (result.pendingPageContent) {
      currentPageContent = result.pendingPageContent;
      pageContentTextarea.value = currentPageContent;
      updateCharCount();
      // 使用後は削除
      await chrome.storage.local.remove('pendingPageContent');
    }
  }

  setupEventListeners();
  setupTabListeners();

  // APIキーを読み込む
  await loadApiKey();

  // サンプル画像にクリックイベントを追加
  setupSampleImageClickEvents();

  // 初期ボタン状態を更新
  updateButtonStates();
});

// デザイン設定を読み込む
async function loadDesignConfig() {
  try {
    const response = await fetch('design/default/design.json');
    designConfig = await response.json();

    // スタイルグリッドを生成
    generateStyleGrid();
  } catch (error) {
    console.error('Failed to load design config:', error);
    alert('デザイン設定の読み込みに失敗しました');
  }
}

// デザイングループを読み込む
async function loadDesignGroups() {
  const result = await chrome.storage.local.get('designGroups');
  if (result.designGroups && Array.isArray(result.designGroups)) {
    designGroups = result.designGroups;
    renderDesignGroups();
  }
}

// デザイングループを保存
async function saveDesignGroups() {
  await chrome.storage.local.set({ designGroups: designGroups });
}


// デザイングループをレンダリング
function renderDesignGroups() {
  const tabNav = document.querySelector('.tab-nav');
  const tabContent = document.querySelector('.tab-content');

  // 既存のカスタムタブを削除
  const customTabs = tabNav.querySelectorAll('.tab-btn[data-custom="true"]');
  customTabs.forEach(tab => tab.remove());

  const customPanes = tabContent.querySelectorAll('.tab-pane[data-custom="true"]');
  customPanes.forEach(pane => pane.remove());

  // デザイングループごとにタブを追加
  designGroups.forEach((group, index) => {
    // タブボタンを追加
    const tabBtn = document.createElement('button');
    tabBtn.className = 'tab-btn';
    tabBtn.dataset.tab = group.id;
    tabBtn.dataset.custom = 'true';
    tabBtn.textContent = group.name;
    tabNav.appendChild(tabBtn);

    // タブコンテンツを追加
    const tabPane = document.createElement('div');
    tabPane.className = 'tab-pane';
    tabPane.id = `tab-${group.id}`;
    tabPane.dataset.custom = 'true';

    // スタイルグリッドを作成
    const styleGrid = document.createElement('div');
    styleGrid.className = 'style-grid';
    styleGrid.dataset.group = group.id;

    // グループのデザインを表示
    if (group.designs && group.designs.length > 0) {
      group.designs.forEach(design => {
        const styleItem = document.createElement('div');
        styleItem.className = 'style-item';
        const sampleImage = design.sampleImage && design.sampleImage !== null ? design.sampleImage : 'design/no_sample_image.jpg';
        styleItem.innerHTML = `
          <div class="design-area">
            <div class="style-label">${design.name}</div>
            <div class="design-wrapper sample-image">
              <img src="${sampleImage}" alt="${design.name}サンプル">
            </div>
            <button class="generate-btn" data-style="${design.id}" data-group="${group.id}">生成</button>
            <div class="design-display" id="design-${group.id}-${design.id}">
              <div class="design-wrapper generated-image">
                <img src="design/first_image.jpg" alt="生成中">
              </div>
            </div>
            <div class="design-actions">
              <button class="action-btn download-btn" data-style="${design.id}" data-group="${group.id}" disabled>ダウンロード</button>
              <button class="action-btn copy-btn" data-style="${design.id}" data-group="${group.id}" disabled>コピー</button>
            </div>
          </div>
        `;
        styleGrid.appendChild(styleItem);
      });
    }

    tabPane.appendChild(styleGrid);
    tabContent.appendChild(tabPane);
  });

  // タブイベントリスナーを再設定
  setupTabListeners();

  // イベントリスナーを再設定
  setupEventListeners();
  setupSampleImageClickEvents();
}

// スタイルグリッドを動的に生成
function generateStyleGrid() {
  const styleGrid = document.querySelector('.style-grid[data-group="home"]');
  if (!styleGrid || !designConfig) return;

  styleGrid.innerHTML = '';

  designConfig.styles.forEach(style => {
    const styleItem = document.createElement('div');
    styleItem.className = 'style-item';
    const sampleImageUrl = style.sampleImage && style.sampleImage !== null ? style.sampleImage : 'design/no_sample_image.jpg';
    styleItem.innerHTML = `
      <div class="design-area">
        <div class="style-label">${style.name}</div>
        <div class="design-wrapper sample-image">
          <img src="${sampleImageUrl}" alt="${style.name}サンプル">
        </div>
        <button class="generate-btn" data-style="${style.id}">生成</button>
        <div class="design-display" id="design-${style.id}">
          <div class="design-wrapper generated-image">
            <img src="design/first_image.jpg" alt="生成中">
          </div>
        </div>
        <div class="design-actions">
          <button class="action-btn download-btn" data-style="${style.id}" disabled>ダウンロード</button>
          <button class="action-btn copy-btn" data-style="${style.id}" disabled>コピー</button>
        </div>
      </div>
    `;
    styleGrid.appendChild(styleItem);
  });

  // イベントリスナーを再設定
  setupEventListeners();
  setupSampleImageClickEvents();
}

// タブリスナーの設定（初回のみ）
let tabListenersSetup = false;

function setupTabListeners() {
  // タブボタンのクリックイベント（イベント委譲を使用）
  if (!tabListenersSetup) {
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('tab-btn')) {
        switchTab(e.target.dataset.tab);
      }
    });
    tabListenersSetup = true;
  }

  // 以下のボタンは初回のみ設定
  if (tabListenersSetup && document.getElementById('addDesignGroupBtn').hasAttribute('data-listener-set')) {
    return;
  }

  // デザイングループ追加ボタン
  const addDesignGroupBtn = document.getElementById('addDesignGroupBtn');
  if (addDesignGroupBtn && !addDesignGroupBtn.hasAttribute('data-listener-set')) {
    addDesignGroupBtn.addEventListener('click', addDesignGroup);
    addDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイングループ編集ボタン
  const editDesignGroupBtn = document.getElementById('editDesignGroupBtn');
  if (editDesignGroupBtn && !editDesignGroupBtn.hasAttribute('data-listener-set')) {
    editDesignGroupBtn.addEventListener('click', openDesignEditModal);
    editDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイングループ削除ボタン
  const deleteDesignGroupBtn = document.getElementById('deleteDesignGroupBtn');
  if (deleteDesignGroupBtn && !deleteDesignGroupBtn.hasAttribute('data-listener-set')) {
    deleteDesignGroupBtn.addEventListener('click', deleteDesignGroup);
    deleteDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // インポートボタン
  const importDesignGroupBtn = document.getElementById('importDesignGroupBtn');
  if (importDesignGroupBtn && !importDesignGroupBtn.hasAttribute('data-listener-set')) {
    importDesignGroupBtn.addEventListener('click', importDesignGroup);
    importDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // エクスポートボタン
  const exportDesignGroupBtn = document.getElementById('exportDesignGroupBtn');
  if (exportDesignGroupBtn && !exportDesignGroupBtn.hasAttribute('data-listener-set')) {
    exportDesignGroupBtn.addEventListener('click', exportDesignGroup);
    exportDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイン編集モーダルの閉じるボタン
  const closeDesignEdit = document.querySelector('.close-design-edit');
  if (closeDesignEdit && !closeDesignEdit.hasAttribute('data-listener-set')) {
    closeDesignEdit.addEventListener('click', closeDesignEditModal);
    closeDesignEdit.setAttribute('data-listener-set', 'true');
  }

  // デザイン編集モーダルのキャンセルボタン
  const cancelDesignEditBtn = document.getElementById('cancelDesignEditBtn');
  if (cancelDesignEditBtn && !cancelDesignEditBtn.hasAttribute('data-listener-set')) {
    cancelDesignEditBtn.addEventListener('click', closeDesignEditModal);
    cancelDesignEditBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイン編集モーダルの保存ボタン
  const saveDesignGroupBtn = document.getElementById('saveDesignGroupBtn');
  if (saveDesignGroupBtn && !saveDesignGroupBtn.hasAttribute('data-listener-set')) {
    saveDesignGroupBtn.addEventListener('click', saveDesignEdits);
    saveDesignGroupBtn.setAttribute('data-listener-set', 'true');
  }

  // デザイン追加ボタン
  const addDesignBtn = document.getElementById('addDesignBtn');
  if (addDesignBtn && !addDesignBtn.hasAttribute('data-listener-set')) {
    addDesignBtn.addEventListener('click', addDesignToEdit);
    addDesignBtn.setAttribute('data-listener-set', 'true');
  }
}

// タブを切り替える
function switchTab(tabId) {
  // すべてのタブボタンとコンテンツからactiveクラスを削除
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabButtons.forEach(btn => btn.classList.remove('active'));
  tabPanes.forEach(pane => pane.classList.remove('active'));

  // 選択されたタブにactiveクラスを追加
  const selectedBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
  const selectedPane = document.getElementById(`tab-${tabId}`);

  if (selectedBtn) selectedBtn.classList.add('active');
  if (selectedPane) selectedPane.classList.add('active');

  activeTab = tabId;

  // ボタンの有効/無効を更新
  updateButtonStates();
}

// ボタンの有効/無効を更新
function updateButtonStates() {
  const editBtn = document.getElementById('editDesignGroupBtn');
  const deleteBtn = document.getElementById('deleteDesignGroupBtn');
  const exportBtn = document.getElementById('exportDesignGroupBtn');

  // ホームタブの場合は編集・削除・エクスポートを無効化
  if (activeTab === 'home') {
    if (editBtn) editBtn.disabled = true;
    if (deleteBtn) deleteBtn.disabled = true;
    if (exportBtn) exportBtn.disabled = true;
  } else {
    if (editBtn) editBtn.disabled = false;
    if (deleteBtn) deleteBtn.disabled = false;
    if (exportBtn) exportBtn.disabled = false;
  }
}

// デザイングループを追加
function addDesignGroup() {
  const groupName = prompt('デザイングループ名を入力してください:');
  if (!groupName || groupName.trim() === '') {
    return;
  }

  // 新しいグループを作成
  const newGroup = {
    id: `group-${Date.now()}`,
    name: groupName.trim(),
    designs: []
  };

  designGroups.push(newGroup);
  saveDesignGroups();
  renderDesignGroups();

  // 新しく作成したタブに切り替える
  switchTab(newGroup.id);
}

// デザイン編集モーダルを開く
function openDesignEditModal() {
  // 現在アクティブなタブのグループを直接編集
  if (activeTab === 'home') {
    alert('ホームは編集できません');
    return;
  }

  const modal = document.getElementById('designEditModal');

  // 現在のアクティブタブを読み込む
  loadGroupForEditing(activeTab);

  modal.classList.add('show');
}

// デザイン編集モーダルを閉じる
function closeDesignEditModal() {
  const modal = document.getElementById('designEditModal');
  modal.classList.remove('show');
  currentEditingGroupId = null;
  tempDesigns = [];
}

// 編集するグループを読み込む
function loadGroupForEditing(groupId) {
  if (!groupId) {
    return;
  }

  currentEditingGroupId = groupId;

  // グループを取得
  const group = designGroups.find(g => g.id === groupId);

  if (!group) return;

  // グループ名を入力フィールドに設定
  const groupNameInput = document.getElementById('groupNameInput');
  if (groupNameInput) {
    groupNameInput.value = group.name;
  }

  // デザインをコピー
  tempDesigns = JSON.parse(JSON.stringify(group.designs || []));

  // デザイン一覧を表示
  renderDesignsForEdit();
}

// 編集用デザイン一覧を表示
function renderDesignsForEdit() {
  const container = document.getElementById('designsContainer');
  const countSpan = document.getElementById('designCount');

  countSpan.textContent = tempDesigns.length;
  container.innerHTML = '';

  tempDesigns.forEach((design, index) => {
    const designItem = document.createElement('div');
    designItem.className = 'design-edit-item';
    designItem.innerHTML = `
      <div class="design-edit-header">
        <span class="design-number">#${index + 1}</span>
        <button class="delete-design-btn" data-index="${index}">🗑️ 削除</button>
      </div>
      <div class="design-edit-form">
        <div class="form-row">
          <div class="form-group">
            <label>ID:</label>
            <input type="text" class="design-id" value="${design.id || ''}" placeholder="例: modern" data-index="${index}">
          </div>
          <div class="form-group">
            <label>名前:</label>
            <input type="text" class="design-name" value="${design.name || ''}" placeholder="例: モダン風" data-index="${index}">
          </div>
        </div>
        <div class="form-group">
          <label>参考画像:</label>
          <div class="image-upload-area" data-index="${index}">
            ${design.sampleImage && design.sampleImage !== null ? `<img src="${design.sampleImage}" alt="サンプル画像" class="preview-image">` : `<img src="design/no_sample_image.jpg" alt="サンプル画像なし" class="preview-image">`}
            <div class="drop-zone ${design.sampleImage && design.sampleImage !== null ? 'has-image' : ''}" data-index="${index}">
              <p>画像をドラッグ＆ドロップ<br>または<br>クリックして選択</p>
              <input type="file" class="file-input" accept="image/*" data-index="${index}" style="display: none;">
            </div>
          </div>
        </div>
        <div class="form-group">
          <label>プロンプト:</label>
          <textarea class="design-prompt" rows="4" placeholder="デザインの説明..." data-index="${index}">${design.prompt || ''}</textarea>
        </div>
      </div>
    `;
    container.appendChild(designItem);

    // イベントリスナーを設定
    setupDesignEditListeners(designItem, index);
  });
}

// デザイン編集アイテムのイベントリスナーを設定
function setupDesignEditListeners(item, index) {
  // 削除ボタン
  const deleteBtn = item.querySelector('.delete-design-btn');
  deleteBtn.addEventListener('click', () => {
    if (confirm('このデザインを削除しますか？')) {
      tempDesigns.splice(index, 1);
      renderDesignsForEdit();
    }
  });

  // ID入力
  const idInput = item.querySelector('.design-id');
  idInput.addEventListener('input', (e) => {
    tempDesigns[index].id = e.target.value;
  });

  // 名前入力
  const nameInput = item.querySelector('.design-name');
  nameInput.addEventListener('input', (e) => {
    tempDesigns[index].name = e.target.value;
  });

  // プロンプト入力
  const promptInput = item.querySelector('.design-prompt');
  promptInput.addEventListener('input', (e) => {
    tempDesigns[index].prompt = e.target.value;
  });

  // ドロップゾーン
  const dropZone = item.querySelector('.drop-zone');
  const fileInput = item.querySelector('.file-input');

  dropZone.addEventListener('click', () => {
    fileInput.click();
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleImageUpload(files[0], index);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleImageUpload(e.target.files[0], index);
    }
  });
}

// 画像アップロード処理
async function handleImageUpload(file, index) {
  if (!file.type.startsWith('image/')) {
    alert('画像ファイルを選択してください');
    return;
  }

  try {
    // 画像をリサイズしてBase64に変換（最大800x800、品質85%）
    const resizedBase64 = await resizeImageToBase64(file, 800, 800, 0.85);
    tempDesigns[index].sampleImage = resizedBase64;
    renderDesignsForEdit();
  } catch (error) {
    console.error('画像のリサイズに失敗:', error);
    alert('画像のアップロードに失敗しました');
  }
}

// デザインを追加
function addDesignToEdit() {
  if (tempDesigns.length >= 32) {
    alert('デザインは最大32個までです');
    return;
  }

  const newDesign = {
    id: '',
    name: '',
    sampleImage: '',
    prompt: ''
  };

  tempDesigns.push(newDesign);
  renderDesignsForEdit();
}

// デザイン編集を保存
function saveDesignEdits() {
  if (!currentEditingGroupId) return;

  // グループ名のバリデーション
  const groupNameInput = document.getElementById('groupNameInput');
  const newGroupName = groupNameInput ? groupNameInput.value.trim() : '';

  if (!newGroupName) {
    alert('グループ名を入力してください');
    return;
  }

  // バリデーション
  for (let i = 0; i < tempDesigns.length; i++) {
    const design = tempDesigns[i];
    if (!design.id || !design.name || !design.prompt) {
      alert(`デザイン #${i + 1}: ID、名前、プロンプトは必須です`);
      return;
    }
  }

  // ID重複チェック
  const designIds = tempDesigns.map(d => d.id);
  const uniqueIds = new Set(designIds);
  if (uniqueIds.size !== designIds.length) {
    const duplicateIds = designIds.filter((id, idx) => designIds.indexOf(id) !== idx);
    const uniqueDuplicates = [...new Set(duplicateIds)];
    showToast(`IDが重複しています: ${uniqueDuplicates.join(', ')}\n各デザインのIDは一意である必要があります。`);
    return;
  }

  // グループを更新
  const group = designGroups.find(g => g.id === currentEditingGroupId);
  if (group) {
    group.name = newGroupName;
    group.designs = tempDesigns;
  }

  // 編集していたグループのIDを保存
  const editedGroupId = currentEditingGroupId;

  saveDesignGroups();
  renderDesignGroups();
  closeDesignEditModal();

  // 編集していたタブに切り替え
  switchTab(editedGroupId);

  showToast('デザインを保存しました');
}

// デザイングループを削除
async function deleteDesignGroup() {
  // 現在アクティブなタブのグループを削除
  if (activeTab === 'home') {
    alert('ホームは削除できません');
    return;
  }

  // 現在のグループを取得
  const group = designGroups.find(g => g.id === activeTab);
  if (!group) {
    alert('削除できるグループがありません');
    return;
  }

  if (!confirm(`「${group.name}」を削除しますか？この操作は取り消せません。`)) {
    return;
  }

  // グループを削除
  const index = designGroups.findIndex(g => g.id === activeTab);
  if (index !== -1) {
    designGroups.splice(index, 1);
    saveDesignGroups();
    renderDesignGroups();

    // ホームタブに切り替え
    switchTab('home');

    showToast('グループを削除しました');
  }
}

// デザイングループをインポート
function importDesignGroup() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.zip';

  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      // zipファイルを読み込む
      const zip = await JSZip.loadAsync(file);

      // design.jsonを取得
      const designJsonFile = zip.file('design.json');
      if (!designJsonFile) {
        showToast('design.jsonが見つかりません');
        return;
      }

      const text = await designJsonFile.async('text');
      const data = JSON.parse(text);

      // バリデーション
      if (!data.name || !Array.isArray(data.designs)) {
        showToast('無効なファイル形式です');
        return;
      }

      // 画像を読み込んでBase64に変換（リサイズ付き）
      const designs = [];
      for (const design of data.designs) {
        const designCopy = { ...design };

        // 画像がある場合、zipから読み込む
        if (design.sampleImage && design.sampleImage.startsWith('images/')) {
          const imagePath = design.sampleImage;
          const imageFile = zip.file(imagePath);

          if (imageFile) {
            const imageBlob = await imageFile.async('blob');

            // Blobをファイルとして扱ってリサイズ
            const file = new File([imageBlob], 'image.jpg', { type: imageBlob.type });
            try {
              const resizedBase64 = await resizeImageToBase64(file, 800, 800, 0.85);
              designCopy.sampleImage = resizedBase64;
            } catch (error) {
              console.error('画像のリサイズに失敗:', error);
              designCopy.sampleImage = '';
            }
          } else {
            designCopy.sampleImage = '';
          }
        }

        designs.push(designCopy);
      }

      // 新しいIDを生成
      const newGroup = {
        id: `group-${Date.now()}`,
        name: data.name,
        designs: designs
      };

      designGroups.push(newGroup);
      saveDesignGroups();
      renderDesignGroups();

      showToast(`「${newGroup.name}」をインポートしました`);
      switchTab(newGroup.id);

    } catch (error) {
      console.error('Import error:', error);
      showToast('インポートに失敗しました: ' + error.message);
    }
  });

  input.click();
}

// デザイングループをエクスポート
async function exportDesignGroup() {
  if (designGroups.length === 0) {
    alert('エクスポートできるグループがありません');
    return;
  }

  // 現在のタブがカスタムグループなら、それをエクスポート
  if (activeTab === 'home') {
    alert('ホームはエクスポートできません。カスタムグループのタブに切り替えてからエクスポートしてください。');
    return;
  }

  const group = designGroups.find(g => g.id === activeTab);

  if (!group) {
    alert('エクスポートするグループを選択してください');
    return;
  }

  try {
    // JSZipインスタンスを作成
    const zip = new JSZip();

    // デザインデータを準備（画像パスは相対パスに変更）
    const exportData = {
      name: group.name,
      designs: group.designs.map(design => ({
        ...design,
        sampleImage: design.sampleImage ? `images/${design.id}.jpg` : ''
      }))
    };

    // design.jsonを追加
    zip.file('design.json', JSON.stringify(exportData, null, 2));

    // imagesフォルダを作成
    const imagesFolder = zip.folder('images');

    // 各デザインのサンプル画像を追加
    for (const design of group.designs) {
      if (design.sampleImage && design.sampleImage.startsWith('data:')) {
        // Base64画像の場合
        const base64Data = design.sampleImage.split(',')[1];
        imagesFolder.file(`${design.id}.jpg`, base64Data, { base64: true });
      } else if (design.sampleImage && design.sampleImage !== 'design/no_sample_image.jpg') {
        // 外部URLの場合は取得してzipに追加
        try {
          const response = await fetch(design.sampleImage);
          const blob = await response.blob();
          imagesFolder.file(`${design.id}.jpg`, blob);
        } catch (error) {
          console.error(`Failed to fetch image for ${design.id}:`, error);
        }
      }
    }

    // zipファイルを生成
    const zipBlob = await zip.generateAsync({ type: 'blob' });

    // ダウンロード
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${group.name}-${Date.now()}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast(`「${group.name}」をエクスポートしました`);
  } catch (error) {
    console.error('Export error:', error);
    showToast('エクスポートに失敗しました: ' + error.message);
  }
}

// イベントリスナーの設定（初回のみ）
let eventListenersSetup = false;

function setupEventListeners() {
  if (eventListenersSetup) return;
  eventListenersSetup = true;

  // テキストエリアの文字数カウント
  pageContentTextarea.addEventListener('input', updateCharCount);

  // 生成ボタン（イベント委譲を使用）
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('generate-btn')) {
      handleStyleSelection(e.target);
    }
  });

  // API設定モーダル
  apiSettingsBtn.addEventListener('click', openApiModal);
  closeModal.addEventListener('click', closeApiModal);
  cancelApiBtn.addEventListener('click', closeApiModal);
  saveApiBtn.addEventListener('click', saveApiKey);

  // 画像拡大モーダル
  imageModal.addEventListener('click', closeImageModal);

  // APIモーダルの外側をクリックしたら閉じる
  window.addEventListener('click', (e) => {
    if (e.target === apiModal) {
      closeApiModal();
    }
  });

  // 画像アップロード機能の初期化
  setupImageUpload();
}

// APIキーの読み込み
async function loadApiKey() {
  const result = await chrome.storage.local.get('falApiKey');
  if (result.falApiKey) {
    falApiKey = result.falApiKey;
  }
}

// APIモーダルを開く
function openApiModal() {
  apiKeyInput.value = falApiKey || '';
  apiModal.classList.add('show');
}

// APIモーダルを閉じる
function closeApiModal() {
  apiModal.classList.remove('show');
}

// 画像拡大モーダルを開く
function openImageModal(imageUrl) {
  modalImage.src = imageUrl;
  imageModal.style.display = 'flex';
}

// 画像拡大モーダルを閉じる
function closeImageModal() {
  imageModal.style.display = 'none';
}

// APIキーを保存
async function saveApiKey() {
  const newApiKey = apiKeyInput.value.trim();
  if (!newApiKey) {
    alert('APIキーを入力してください');
    return;
  }

  falApiKey = newApiKey;
  await chrome.storage.local.set({ falApiKey: newApiKey });
  alert('APIキーを保存しました');
  closeApiModal();
}

// サンプル画像のクリックイベントを設定
// サンプル画像クリックイベント（初回のみ、イベント委譲を使用）
let sampleImageListenerSetup = false;

function setupSampleImageClickEvents() {
  if (sampleImageListenerSetup) return;
  sampleImageListenerSetup = true;

  document.addEventListener('click', (e) => {
    if (e.target.tagName === 'IMG' && e.target.closest('.sample-image')) {
      openImageModal(e.target.src);
    }
  });
}

// 文字数カウントの更新
function updateCharCount() {
  const count = pageContentTextarea.value.length;
  charCountSpan.textContent = count.toLocaleString();
}

// スタイル選択の処理
async function handleStyleSelection(button) {
  const style = button.dataset.style;
  const groupId = button.dataset.group || 'home';
  const displayContainerId = groupId === 'home' ? `design-${style}` : `design-${groupId}-${style}`;
  const displayContainer = document.getElementById(displayContainerId);
  const designArea = button.closest('.design-area');
  const downloadBtn = designArea.querySelector('.download-btn');
  const copyBtn = designArea.querySelector('.copy-btn');

  // ボタンを無効化
  button.disabled = true;

  // 生成中の画像要素を取得
  const generatedImageWrapper = displayContainer.querySelector('.generated-image');

  // ローディング表示を生成画像の上に追加
  const loadingDiv = document.createElement('div');
  loadingDiv.className = 'design-loading';
  loadingDiv.innerHTML = '<div class="design-spinner"></div><div class="design-loading-text">生成中...</div>';
  generatedImageWrapper.appendChild(loadingDiv);

  try {
    // サムネイル生成
    const imageUrl = await generateThumbnail(style, groupId);

    // ローディング表示を削除
    generatedImageWrapper.removeChild(loadingDiv);

    // 生成された画像に入れ替え
    if (generatedImageWrapper) {
      const img = generatedImageWrapper.querySelector('img');
      img.src = imageUrl;
      img.alt = `${style}スタイルのデザイン`;
      img.addEventListener('click', () => openImageModal(imageUrl));
    }

    // 生成画像を保存
    if (!generatedImages[style]) {
      generatedImages[style] = [];
    }
    generatedImages[style].push(imageUrl);

    // ダウンロード・コピーボタンを有効化し、最新画像に対応
    downloadBtn.disabled = false;
    copyBtn.disabled = false;

    downloadBtn.onclick = () => downloadImage(imageUrl, style);
    copyBtn.onclick = () => copyImageToClipboard(imageUrl);

  } catch (error) {
    // エラーログは表示しない（タイムアウトなどは正常な動作）
    console.log('Generation stopped:', error.message);

    // ローディング表示を削除
    if (generatedImageWrapper.contains(loadingDiv)) {
      generatedImageWrapper.removeChild(loadingDiv);
    }

    // タイムアウトの場合は再試行を促すメッセージ
    const messageDiv = document.createElement('div');
    messageDiv.className = 'design-loading';
    messageDiv.style.cursor = 'default';

    if (error.message && error.message.includes('タイムアウト')) {
      messageDiv.innerHTML = `
        <div style="color: #e67e22; font-size: 14px; font-weight: bold;">タイムアウトしました</div>
        <div style="color: #7f8c8d; font-size: 12px; margin-top: 8px;">もう一度「生成」ボタンを押してください</div>
      `;
    } else {
      messageDiv.innerHTML = `
        <div style="color: #e74c3c; font-size: 14px; font-weight: bold;">生成に失敗しました</div>
        <div style="color: #7f8c8d; font-size: 12px; margin-top: 8px;">もう一度「生成」ボタンを押してください</div>
      `;
    }

    generatedImageWrapper.appendChild(messageDiv);

    // 5秒後にメッセージを削除
    setTimeout(() => {
      if (generatedImageWrapper.contains(messageDiv)) {
        generatedImageWrapper.removeChild(messageDiv);
      }
    }, 5000);
  } finally {
    // ボタンを元に戻す
    button.disabled = false;
  }
}

// サムネイル生成
async function generateThumbnail(style, groupId = 'home') {
  // 画像生成API呼び出し
  const imageUrl = await callImageGenerationAPI(style, groupId);

  return imageUrl;
}

// 選択されたテーマカラーを取得
function getSelectedThemeColor() {
  const selectedRadio = document.querySelector('input[name="themeColor"]:checked');
  return selectedRadio ? selectedRadio.value : 'auto';
}

// 画像生成API呼び出し
async function callImageGenerationAPI(style, groupId = 'home') {
  console.log('Generating image with style:', style, 'groupId:', groupId);

  // APIキーのチェック
  if (!falApiKey) {
    throw new Error('FAL APIキーが設定されていません。API設定から設定してください。');
  }

  // タイトルとページ内容を取得
  const title = titleInput.value.trim();
  const content = pageContentTextarea.value;

  // テーマカラーを取得
  const themeColor = getSelectedThemeColor();

  // プロンプトを取得
  let stylePrompt = '';

  if (groupId === 'home') {
    // ホームタブの場合はデフォルトのデザイン設定から取得
    const styleConfig = designConfig.styles.find(s => s.id === style);
    stylePrompt = styleConfig ? styleConfig.prompt : '';
  } else {
    // カスタムグループの場合はグループのデザイン設定から取得
    const group = designGroups.find(g => g.id === groupId);
    if (group && group.designs) {
      const design = group.designs.find(d => d.id === style);
      stylePrompt = design ? design.prompt : '';
    }
  }

  // テーマカラーに応じた色指定
  const colorInstructions = {
    auto: '',
    red: '\n- Primary color scheme: Red tones (#e74c3c, crimson, burgundy)',
    blue: '\n- Primary color scheme: Blue tones (#3498db, navy, sky blue)',
    green: '\n- Primary color scheme: Green tones (#2ecc71, forest green, emerald)',
    yellow: '\n- Primary color scheme: Yellow tones (#f1c40f, gold, amber)',
    purple: '\n- Primary color scheme: Purple tones (#9b59b6, violet, lavender)',
    orange: '\n- Primary color scheme: Orange tones (#e67e22, coral, tangerine)',
    pink: '\n- Primary color scheme: Pink tones (#ec7aa5, rose, magenta)',
    white: '\n- Primary color scheme: White and light tones (#ffffff, ivory, cream, light gray)',
    navy: '\n- Primary color scheme: Navy tones (#34495e, dark blue, midnight blue)',
    gray: '\n- Primary color scheme: Gray tones (#95a5a6, silver, charcoal)',
    black: '\n- Primary color scheme: Black and dark tones (#2c3e50, charcoal, slate)'
  };

  // プロンプトを生成（タイトルと記事本文を含める）
  let fullPrompt = stylePrompt;

  // テーマカラーの指定を追加
  if (themeColor !== 'auto') {
    fullPrompt += colorInstructions[themeColor] || '';
  }

  // コンテンツ処理の指示を追加
  fullPrompt += '\n\nContent Guidelines:';
  fullPrompt += '\n- Focus on the core topic and main message from the article';
  fullPrompt += '\n- Include dates ONLY if they are central to the story (e.g., historical events, commemorations, time-sensitive announcements)';
  fullPrompt += '\n- Exclude irrelevant metadata like publication dates, last updated timestamps, author names, or page numbers';
  fullPrompt += '\n- DO NOT include temporal/dimensional information such as: "today\'s date" (今日の日付), "article count" (残り記事数), "reading time estimates", "view counts", "share counts", or similar statistics';
  fullPrompt += '\n- Extract and emphasize the key points that would attract viewers';

  fullPrompt += '\n\n';

  if (title) {
    fullPrompt += `タイトル: ${title}\n\n`;
  }

  fullPrompt += `記事本文:\n${content.substring(0, 1000)}`;

  // 選択されたアスペクト比を取得
  const aspectRatio = aspectRatioSelect.value;

  // サンプル画像のパスを取得
  let sampleImagePath = '';
  if (groupId === 'home') {
    const styleConfig = designConfig.styles.find(s => s.id === style);
    sampleImagePath = styleConfig ? styleConfig.sampleImage : '';
  } else {
    const group = designGroups.find(g => g.id === groupId);
    if (group && group.designs) {
      const design = group.designs.find(d => d.id === style);
      sampleImagePath = design ? design.sampleImage : '';
    }
  }

  // 参考画像の有無を判定してeditエンドポイントを使用するか決定
  let useEditEndpoint = false;
  const imageUrls = [];

  console.log('=== 画像アップロード処理開始 ===');
  console.log('サンプル画像パス:', sampleImagePath);
  console.log('キャラクター画像あり:', !!characterImageBase64);
  console.log('デザイン参考画像あり:', !!designImageBase64);

  // サンプル画像、キャラクター画像、デザイン参考画像のいずれかがある場合はeditエンドポイントを使用
  // nullの場合は画像なしとして扱う
  const hasAnyImage = (sampleImagePath && sampleImagePath !== null) || characterImageBase64 || designImageBase64;

  if (hasAnyImage) {
    useEditEndpoint = true;
    console.log('参考画像が存在するため、editエンドポイントを使用します');

    // サンプル画像を最初に追加（スタイルの基準として）
    // nullの場合はスキップ
    if (sampleImagePath && sampleImagePath !== null) {
      try {
        console.log('サンプル画像を処理中:', sampleImagePath);

        // Base64データURIに変換
        let sampleImageDataUri;
        if (sampleImagePath.startsWith('data:')) {
          console.log('サンプル画像はすでにBase64データURIです');
          sampleImageDataUri = sampleImagePath;
        } else {
          console.log('サンプル画像をBase64データURIに変換します');
          sampleImageDataUri = await convertImageToBase64(sampleImagePath);
        }

        if (sampleImageDataUri) {
          // FAL CDNにアップロードを試行
          const uploadResult = await uploadToFalCDN(sampleImageDataUri, 'sample.jpg');

          if (uploadResult.url) {
            console.log('✓ サンプル画像をFAL CDNにアップロード成功:', uploadResult.url);
            imageUrls.push(uploadResult.url);
          } else {
            console.warn('⚠ FAL CDNアップロード失敗、Base64にフォールバック');
            imageUrls.push(sampleImageDataUri);
          }
        } else {
          console.warn('⚠ サンプル画像の変換に失敗しました');
        }
      } catch (error) {
        console.error('✗ サンプル画像の処理に失敗しました:', error);
        console.error('エラー詳細:', error.message);
      }
    }

    // キャラクター画像を追加
    if (characterImageBase64) {
      try {
        console.log('キャラクター画像を処理中');

        // FAL CDNにアップロードを試行
        const uploadResult = await uploadToFalCDN(characterImageBase64, 'character.jpg');

        if (uploadResult.url) {
          console.log('✓ キャラクター画像をFAL CDNにアップロード成功:', uploadResult.url);
          imageUrls.push(uploadResult.url);
        } else {
          console.warn('⚠ FAL CDNアップロード失敗、Base64にフォールバック');
          imageUrls.push(characterImageBase64);
        }
      } catch (error) {
        console.error('✗ キャラクター画像の処理に失敗、Base64を使用:', error);
        imageUrls.push(characterImageBase64);
      }
    }

    // デザイン参考画像を追加
    if (designImageBase64) {
      try {
        console.log('デザイン参考画像を処理中');

        // FAL CDNにアップロードを試行
        const uploadResult = await uploadToFalCDN(designImageBase64, 'design.jpg');

        if (uploadResult.url) {
          console.log('✓ デザイン参考画像をFAL CDNにアップロード成功:', uploadResult.url);
          imageUrls.push(uploadResult.url);
        } else {
          console.warn('⚠ FAL CDNアップロード失敗、Base64にフォールバック');
          imageUrls.push(designImageBase64);
        }
      } catch (error) {
        console.error('✗ デザイン参考画像の処理に失敗、Base64を使用:', error);
        imageUrls.push(designImageBase64);
      }
    }

    console.log('=== 画像アップロード処理完了 ===');
    console.log('アップロードされた画像数:', imageUrls.length);
    console.log('画像URLs:', imageUrls);
  } else {
    console.log('参考画像がないため、通常のエンドポイントを使用します');
  }

  // APIリクエストボディの構築
  const requestBody = {
    prompt: fullPrompt,
    num_images: 1,
    aspect_ratio: aspectRatio,
    output_format: 'jpeg',
    resolution: '1K'
  };

  // 参考画像がある場合は追加（image_urlsパラメータを使用）
  if (useEditEndpoint && imageUrls.length > 0) {
    requestBody.image_urls = imageUrls;

    // プロンプトに参考画像の指示を追加
    let imageInstructions = '\n\n参考画像の使用指示:';

    // サンプル画像の指示（スタイルのベースとなる画像）
    // nullの場合はスキップ
    if (sampleImagePath && sampleImagePath !== null) {
      imageInstructions += '\n- Sample image (1st image): Use this as a comprehensive style reference. IMPORTANT: Match the overall atmosphere, composition, layout structure, text amount and placement, visual hierarchy, graphic element styles, and design patterns. However, DO NOT create an exact copy - maintain originality by using the specified theme color, adapting the content to the article topic, and creating unique visual elements while preserving the same design language and aesthetic feel. Think of it as creating a design in the same style and mood, not duplicating the reference.';
    }

    // キャラクター画像の指示
    if (characterImageBase64) {
      imageInstructions += '\n- Character image: Include this character in the thumbnail with an appropriate facial expression and pose that fits the article content and mood. Maintain the character\'s design and features accurately.';
    }

    // デザイン参考画像の指示
    if (designImageBase64) {
      imageInstructions += '\n- Design reference image: Use this as a comprehensive reference including structure, composition, color scheme, layout, and overall aesthetic. Follow this design direction closely.';
    }

    requestBody.prompt += imageInstructions;
  }

  // 使用するAPIエンドポイントを決定
  const apiEndpoint = useEditEndpoint
    ? 'https://queue.fal.run/fal-ai/nano-banana-pro/edit'
    : 'https://queue.fal.run/fal-ai/nano-banana-pro';

  console.log('=== API リクエスト情報 ===');
  console.log('サンプル画像パス:', sampleImagePath);
  console.log('editエンドポイント使用:', useEditEndpoint);
  console.log('使用するエンドポイント:', apiEndpoint);
  console.log('参考画像数:', imageUrls.length);
  if (imageUrls.length > 0) {
    console.log('画像URL:', imageUrls);
  }
  console.log('リクエストボディ:', JSON.stringify(requestBody, null, 2));
  console.log('image_urlsパラメータが含まれているか:', 'image_urls' in requestBody);
  if ('image_urls' in requestBody) {
    console.log('image_urlsの内容:', requestBody.image_urls);
  }

  // FAL AI APIを呼び出す
  try {
    const response = await fetch(apiEndpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Key ${falApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`API Error: ${response.status} - ${errorData.detail || response.statusText}`);
    }

    const data = await response.json();
    console.log('FAL API Response:', data);

    // request_idを取得
    const requestId = data.request_id;
    const statusUrl = data.status_url || `${apiEndpoint}/requests/${requestId}/status`;
    const resultUrl = data.response_url || `${apiEndpoint}/requests/${requestId}`;

    console.log('Polling URLs:', {
      requestId,
      statusUrl,
      resultUrl
    });

    // ポーリングで結果を取得
    const result = await pollForResult(requestId, statusUrl, resultUrl);

    // 画像URLを返す
    if (result.images && result.images.length > 0) {
      return result.images[0].url;
    } else {
      throw new Error('画像の生成に失敗しました');
    }

  } catch (error) {
    console.error('FAL API Error:', error);
    throw error;
  }
}

// 結果をポーリングで取得（app.jsの実装を参考）
async function pollForResult(requestId, statusUrl, resultUrl) {
  console.log(`FAL AIキューからの結果取得を開始: request_id: ${requestId}`);

  const maxRetries = 60; // 最大60回（5秒 × 60 = 5分）
  const retryInterval = 5000; // 5秒ごと

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // 5秒待機
      await new Promise(resolve => setTimeout(resolve, retryInterval));

      console.log(`ステータス確認 (試行 ${attempt + 1}/${maxRetries}): ${statusUrl}`);

      // ステータスをチェック
      const statusResponse = await fetch(statusUrl, {
        headers: {
          'Authorization': `Key ${falApiKey}`
        }
      });

      if (!statusResponse.ok) {
        throw new Error(`Status check failed: ${statusResponse.status}`);
      }

      const statusData = await statusResponse.json();
      console.log('Status check response:', {
        status: statusData.status,
        hasImages: !!(statusData.images && statusData.images.length > 0),
        attempt: attempt + 1
      });

      // COMPLETEDの場合
      if (statusData.status === 'COMPLETED') {
        // まずstatusDataにimagesがあるか確認
        if (statusData.images && statusData.images.length > 0) {
          console.log('✓ Result found in status response, returning directly');
          return statusData;
        }

        // statusDataにimagesがない場合、resultUrlから取得
        console.log('Fetching result from:', resultUrl);
        try {
          const resultResponse = await fetch(resultUrl, {
            headers: {
              'Authorization': `Key ${falApiKey}`
            }
          });

          console.log('Result fetch response status:', resultResponse.status);

          if (!resultResponse.ok) {
            console.warn(`⚠ Result fetch failed with status ${resultResponse.status}`);
            // result取得失敗でもstatusDataがあれば使用
            if (statusData) {
              console.log('Using statusData as fallback (response not ok)');
              return statusData;
            }
            throw new Error(`Result fetch failed: ${resultResponse.status}`);
          }

          const result = await resultResponse.json();
          console.log('✓ Result fetched successfully:', {
            hasImages: !!(result.images && result.images.length > 0),
            hasData: !!(result.data)
          });
          return result;
        } catch (resultError) {
          console.error('✗ Result fetch error:', resultError);
          // result取得エラーでもstatusDataがあれば使用
          if (statusData) {
            console.log('Using statusData as fallback (error caught)');
            return statusData;
          }
          throw resultError;
        }
      } else if (statusData.status === 'FAILED') {
        throw new Error(statusData.error || '画像生成に失敗しました');
      }

      // 進捗表示（ログがある場合）
      if (statusData.logs && statusData.logs.length > 0) {
        const lastLog = statusData.logs[statusData.logs.length - 1];
        console.log(`生成中: ${lastLog.message || '処理中...'}`);
      }

    } catch (error) {
      console.error(`結果取得エラー (試行 ${attempt + 1}):`, error);

      // 最後の試行でない場合は再試行
      if (attempt < maxRetries - 1) {
        console.log('再試行します...');
        continue;
      }

      throw error;
    }
  }

  throw new Error('タイムアウト: 画像生成に時間がかかりすぎています');
}

// 画像をダウンロード
async function downloadImage(imageUrl, style) {
  try {
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = `design-${style}-${Date.now()}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    showToast('画像をダウンロードしました');
  } catch (error) {
    console.error('Download error:', error);
    showToast('ダウンロードに失敗しました: ' + error.message);
  }
}

// 画像をクリップボードにコピー
async function copyImageToClipboard(imageUrl) {
  try {
    const response = await fetch(imageUrl);
    const blob = await response.blob();

    // PNGに変換してコピー
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.crossOrigin = 'anonymous';
    img.src = imageUrl;

    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
    });

    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);

    canvas.toBlob(async (pngBlob) => {
      await navigator.clipboard.write([
        new ClipboardItem({
          'image/png': pngBlob
        })
      ]);
      alert('クリップボードにコピーしました');
    }, 'image/png');

  } catch (error) {
    console.error('Clipboard copy error:', error);
    alert('クリップボードへのコピーに失敗しました: ' + error.message);
  }
}

// 画像アップロード機能の初期化
function setupImageUpload() {
  // キャラクター画像
  const characterZone = document.getElementById('characterImageZone');
  const characterInput = document.getElementById('characterImageInput');
  const characterPreview = document.getElementById('characterPreview');
  const removeCharacterBtn = document.getElementById('removeCharacterBtn');

  // デザイン参考画像
  const designZone = document.getElementById('designImageZone');
  const designInput = document.getElementById('designImageInput');
  const designPreview = document.getElementById('designPreview');
  const removeDesignBtn = document.getElementById('removeDesignBtn');

  // キャラクター画像のイベント設定
  setupImageUploadZone(characterZone, characterInput, characterPreview, removeCharacterBtn, 'character');

  // デザイン参考画像のイベント設定
  setupImageUploadZone(designZone, designInput, designPreview, removeDesignBtn, 'design');
}

// 画像アップロードゾーンのイベント設定
function setupImageUploadZone(zone, input, preview, removeBtn, type) {
  // クリックでファイル選択
  zone.addEventListener('click', (e) => {
    if (e.target === removeBtn) return;
    input.click();
  });

  // ファイル選択時の処理
  input.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      handleImageFile(file, preview, removeBtn, zone, type);
    }
  });

  // ドラッグオーバー時のスタイル変更
  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('dragover');
  });

  zone.addEventListener('dragleave', (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');
  });

  // ドロップ時の処理
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');

    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      handleImageFile(file, preview, removeBtn, zone, type);
    } else {
      showToast('画像ファイルをドロップしてください');
    }
  });

  // 削除ボタンのイベント
  removeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    removeImage(preview, removeBtn, zone, type);
  });
}

// 画像ファイルの処理
async function handleImageFile(file, preview, removeBtn, zone, type) {
  // ファイルサイズチェック（10MB以下）
  if (file.size > 10 * 1024 * 1024) {
    showToast('画像サイズは10MB以下にしてください');
    return;
  }

  try {
    // 画像をリサイズしてBase64に変換（最大800x800、品質85%）
    const resizedBase64 = await resizeImageToBase64(file, 800, 800, 0.85);

    // プレビュー表示
    preview.src = resizedBase64;
    preview.style.display = 'block';
    removeBtn.style.display = 'block';

    // placeholderを非表示
    const placeholder = zone.querySelector('.upload-placeholder');
    if (placeholder) {
      placeholder.style.display = 'none';
    }

    // Base64データを保存
    if (type === 'character') {
      characterImageBase64 = resizedBase64;
    } else if (type === 'design') {
      designImageBase64 = resizedBase64;
    }

    showToast(`${type === 'character' ? 'キャラクター' : 'デザイン参考'}画像をアップロードしました（リサイズ済み）`);
  } catch (error) {
    console.error('画像の処理に失敗:', error);
    showToast('画像の読み込みに失敗しました');
  }
}

// 画像の削除
function removeImage(preview, removeBtn, zone, type) {
  preview.style.display = 'none';
  preview.src = '';
  removeBtn.style.display = 'none';

  // placeholderを表示
  const placeholder = zone.querySelector('.upload-placeholder');
  if (placeholder) {
    placeholder.style.display = 'block';
  }

  // Base64データをクリア
  if (type === 'character') {
    characterImageBase64 = null;
  } else if (type === 'design') {
    designImageBase64 = null;
  }

  // input要素をリセット
  const input = zone.querySelector('input[type="file"]');
  if (input) {
    input.value = '';
  }

  showToast(`${type === 'character' ? 'キャラクター' : 'デザイン参考'}画像を削除しました`);
}

// 画像をリサイズしてBase64に変換
async function resizeImageToBase64(file, maxWidth = 800, maxHeight = 800, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();

      img.onload = () => {
        // 元の画像サイズ
        let width = img.width;
        let height = img.height;

        // アスペクト比を保ったままリサイズ
        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width = Math.floor(width * ratio);
          height = Math.floor(height * ratio);
        }

        // Canvasで描画
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        // Base64に変換
        const resizedBase64 = canvas.toDataURL('image/jpeg', quality);
        resolve(resizedBase64);
      };

      img.onerror = () => reject(new Error('画像の読み込みに失敗しました'));
      img.src = e.target.result;
    };

    reader.onerror = () => reject(new Error('ファイルの読み込みに失敗しました'));
    reader.readAsDataURL(file);
  });
}

// Base64データURIをBlobに変換
function base64ToBlob(base64Data) {
  const parts = base64Data.split(';base64,');
  const contentType = parts[0].split(':')[1];
  const raw = window.atob(parts[1]);
  const rawLength = raw.length;
  const uInt8Array = new Uint8Array(rawLength);

  for (let i = 0; i < rawLength; ++i) {
    uInt8Array[i] = raw.charCodeAt(i);
  }

  return new Blob([uInt8Array], { type: contentType });
}

// 画像URLをBase64 data URIに変換
async function convertImageToBase64(imagePath) {
  try {
    console.log('画像を読み込み中:', imagePath);
    const response = await fetch(imagePath);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.status}`);
    }
    const blob = await response.blob();
    console.log(`画像読み込み完了 (size: ${blob.size} bytes, type: ${blob.type})`);

    // BlobをBase64に変換
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        console.log('Base64変換完了');
        resolve(reader.result);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('画像の変換に失敗しました:', error);
    throw error;
  }
}

// FAL CDNに画像をアップロード（Base64 data URIから）
async function uploadToFalCDN(base64DataUri, filename) {
  console.log(`FAL CDNへのアップロード開始: ${filename}`);

  try {
    // Base64 data URIからBlobに変換
    const blob = base64ToBlob(base64DataUri);
    const mimeType = blob.type;
    console.log(`Blob作成完了 (size: ${blob.size} bytes, type: ${mimeType})`);

    // Step 1: 2段階アップロード方式を試行
    const initiateEndpoints = [
      'https://rest.alpha.fal.ai/storage/upload/initiate?storage_type=fal-cdn-v3',
      'https://rest.alpha.fal.ai/storage/upload/initiate?storage_type=fal-cdn',
      'https://rest.alpha.fal.ai/storage/upload/initiate'
    ];

    for (const endpoint of initiateEndpoints) {
      try {
        console.log(`Initiate試行中: ${endpoint}`);

        // 2-1. Initiate request
        const initiateRes = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Authorization': `Key ${falApiKey}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            content_type: mimeType,
            file_name: filename
          })
        });

        if (!initiateRes.ok) {
          console.warn(`Initiate失敗 (${initiateRes.status}): ${endpoint}`);
          continue;
        }

        const data = await initiateRes.json();
        const uploadUrl = data.upload_url || data.uploadUrl;
        const fileUrl = data.file_url || data.fileUrl || data.url;

        if (!uploadUrl || !fileUrl) {
          console.warn('Upload URLまたはFile URLが取得できませんでした');
          continue;
        }

        console.log(`Initiate成功! File URL: ${fileUrl}`);

        // 2-2. Upload (PUT request)
        console.log(`実際のアップロード中: ${uploadUrl}`);
        const uploadRes = await fetch(uploadUrl, {
          method: 'PUT',
          headers: { 'Content-Type': mimeType },
          body: blob
        });

        if (!uploadRes.ok) {
          console.warn(`Upload失敗 (${uploadRes.status})`);
          continue;
        }

        // 成功！
        console.log(`✓ FAL CDNアップロード成功: ${fileUrl}`);
        return { url: fileUrl, error: null };

      } catch (err) {
        console.warn(`Initiate/Upload失敗: ${endpoint}`, err);
        continue;
      }
    }

    // Step 2: フォールバック - FormData方式
    console.log('2段階アップロード失敗、FormData方式を試行');
    const legacyEndpoints = [
      'https://api.fal.ai/v1/storage/upload',
      'https://api.fal.run/v1/storage/upload',
      'https://fal.run/api/v1/storage/upload',
      'https://fal.ai/api/v1/storage/upload'
    ];

    for (const endpoint of legacyEndpoints) {
      try {
        console.log(`FormDataアップロード試行中: ${endpoint}`);

        const formData = new FormData();
        formData.append('file', blob, filename);
        formData.append('content_type', mimeType);
        formData.append('filename', filename);

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Authorization': `Key ${falApiKey}` },
          body: formData
        });

        if (!response.ok) {
          console.warn(`FormDataアップロード失敗 (${response.status}): ${endpoint}`);
          continue;
        }

        const data = await response.json();
        const url = data.url || data.file_url || data.fileUrl;

        if (url) {
          console.log(`✓ FormDataアップロード成功: ${url}`);
          return { url, error: null };
        }

      } catch (err) {
        console.warn(`FormDataアップロード失敗: ${endpoint}`, err);
        continue;
      }
    }

    // 全て失敗
    console.error('✗ 全てのアップロード方式が失敗しました');
    return { url: '', error: new Error('All upload attempts failed') };

  } catch (error) {
    console.error('✗ アップロード処理でエラーが発生:', error);
    return { url: '', error };
  }
}

// Base64画像をFAL AIにアップロード
async function uploadBase64ToFal(base64Data, imageType) {
  try {
    console.log(`${imageType}画像のアップロード開始`);
    // Base64をBlobに変換
    const blob = base64ToBlob(base64Data);
    console.log(`Blob作成完了 (size: ${blob.size} bytes, type: ${blob.type})`);

    // FormDataを作成
    const formData = new FormData();
    formData.append('file', blob, `${imageType}.jpg`);

    console.log('FAL AIストレージAPIにアップロード中...');
    // FAL AIのストレージAPIにアップロード
    const response = await fetch('https://fal.run/storage/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Key ${falApiKey}`
      },
      body: formData
    });

    console.log(`アップロードレスポンス status: ${response.status}`);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('アップロードエラー:', errorText);
      throw new Error(`Upload failed: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log(`${imageType} image uploaded successfully:`, data);

    // FAL AIのレスポンス形式に応じてURLを取得
    return data.url || data.file_url || data.access_url;
  } catch (error) {
    console.error(`Failed to upload ${imageType} image:`, error);
    throw error;
  }
}

// ローカル画像パスからBlobを取得してFAL AIにアップロード
async function uploadImageToFal(imagePath, imageType) {
  try {
    console.log(`${imageType}画像をローカルから読み込み中: ${imagePath}`);
    // 画像をfetchで取得
    const response = await fetch(imagePath);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.status}`);
    }
    const blob = await response.blob();
    console.log(`Blob作成完了 (size: ${blob.size} bytes, type: ${blob.type})`);

    // FormDataを作成
    const formData = new FormData();
    formData.append('file', blob, `${imageType}.jpg`);

    console.log('FAL AIストレージAPIにアップロード中...');
    // FAL AIのストレージAPIにアップロード
    const uploadResponse = await fetch('https://fal.run/api/upload', {
      method: 'POST',
      headers: {
        'Authorization': `Key ${falApiKey}`
      },
      body: formData
    });

    console.log(`アップロードレスポンス status: ${uploadResponse.status}`);

    if (!uploadResponse.ok) {
      const errorText = await uploadResponse.text();
      console.error('アップロードエラー:', errorText);
      throw new Error(`Upload failed: ${uploadResponse.status} - ${errorText}`);
    }

    const data = await uploadResponse.json();
    console.log(`${imageType} image uploaded successfully:`, data);

    // FAL AIのレスポンス形式に応じてURLを取得
    return data.url || data.file_url || data.access_url;
  } catch (error) {
    console.error(`Failed to upload ${imageType} image:`, error);
    throw error;
  }
}

